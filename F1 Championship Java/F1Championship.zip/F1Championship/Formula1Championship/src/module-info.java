/**
 * 
 */
/**
 * @author paulnyakeru
 *
 */
module Formula1Championship {
}